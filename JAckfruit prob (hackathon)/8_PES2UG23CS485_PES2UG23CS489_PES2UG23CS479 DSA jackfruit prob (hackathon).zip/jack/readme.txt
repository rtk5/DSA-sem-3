to run -->  gcc jack.c
            ./a.out